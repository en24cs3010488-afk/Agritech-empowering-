import { useEffect, useState } from "react";
import { Link, NavLink, Route, Routes, useNavigate } from "react-router-dom";
import api from "./api.js";

const demoWeather = [
  { place: "Indore (sample)", temp: "29°C", condition: "Partly cloudy", note: "Check local forecast before irrigation." },
  { place: "Bhopal (sample)", temp: "28°C", condition: "Cloudy", note: "Demo values only; not a live forecast." }
];
const market = [
  { crop: "Wheat", price: "₹2,425 / quintal", source: "Illustrative sample" },
  { crop: "Soybean", price: "₹4,600 / quintal", source: "Illustrative sample" },
  { crop: "Maize", price: "₹2,225 / quintal", source: "Illustrative sample" }
];

function Header({ user, logout }) {
  return <nav className="navbar navbar-expand-lg navbar-dark app-nav">
    <div className="container"><Link className="navbar-brand fw-bold" to="/">🌱 AgriSmart</Link>
      <div className="d-flex flex-wrap gap-3 align-items-center">
        <NavLink className="nav-link" to="/">Home</NavLink>
        {user && <NavLink className="nav-link" to="/dashboard">Dashboard</NavLink>}
        {user ? <button className="btn btn-sm btn-outline-light" onClick={logout}>Logout</button> : <><Link className="btn btn-sm btn-outline-light" to="/login">Login</Link><Link className="btn btn-sm btn-warning" to="/register">Join as Farmer</Link></>}
      </div>
    </div>
  </nav>;
}
function Home() {
  return <><section className="hero"><div className="container py-5">
    <span className="eyebrow">SMART FARMING · BETTER FUTURE</span>
    <h1 className="display-4 fw-bold mt-3">Technology that grows<br/>with your farm.</h1>
    <p className="lead mt-3">One simple place to manage your farm, track crops, and explore practical farming resources.</p>
    <Link to="/register" className="btn btn-warning btn-lg mt-2">Get Started →</Link>
  </div></section>
  <div className="container py-5"><div className="row g-4">
    {[["🌾","Farm & Crop Management","Keep farm details and crop records in one place."],["🌦️","Weather & Pest Alerts","Explore demo alerts and learn what to monitor."],["🧑‍🌾","Farmer-first Design","A simple, responsive interface for everyday use."]].map(([icon,title,desc])=><div className="col-md-4" key={title}><div className="feature-card h-100"><div className="feature-icon">{icon}</div><h3>{title}</h3><p>{desc}</p></div></div>)}
  </div><div className="alert alert-warning mt-4 mb-0"><strong>Demo notice:</strong> Weather and market figures in this starter are sample data, not live agricultural advice or current prices.</div></div></>;
}
function AuthForm({ mode, onAuth }) {
  const [form, setForm] = useState({ name:"", email:"", password:"", phone:"", language:"Hindi" });
  const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  const nav = useNavigate();
  const update = e => setForm({ ...form, [e.target.name]: e.target.value });
  async function submit(e) {
    e.preventDefault(); setError(""); setBusy(true);
    try {
      const { data } = await api.post(`/auth/${mode}`, form);
      localStorage.setItem("agritech_token", data.token);
      onAuth(data.user); nav("/dashboard");
    } catch (err) { setError(err.response?.data?.message || "Could not connect. Is the backend running?"); }
    finally { setBusy(false); }
  }
  return <div className="container py-5"><div className="auth-card mx-auto"><h2>{mode === "login" ? "Welcome back" : "Create your farmer account"}</h2><p className="text-muted">{mode === "login" ? "Log in to manage your farm." : "Join AgriSmart to start managing your farm."}</p>
    {error && <div className="alert alert-danger">{error}</div>}
    <form onSubmit={submit} className="d-grid gap-3">
      {mode === "register" && <><input className="form-control" name="name" placeholder="Full name" value={form.name} onChange={update} required/><input className="form-control" name="phone" placeholder="Phone (optional)" value={form.phone} onChange={update}/><select className="form-select" name="language" value={form.language} onChange={update}><option>Hindi</option><option>English</option><option>Marathi</option></select></>}
      <input className="form-control" name="email" type="email" placeholder="Email address" value={form.email} onChange={update} required/>
      <input className="form-control" name="password" type="password" minLength="8" placeholder="Password (minimum 8 characters)" value={form.password} onChange={update} required/>
      <button className="btn btn-success btn-lg" disabled={busy}>{busy ? "Please wait..." : mode === "login" ? "Login" : "Register"}</button>
    </form>
    <p className="mt-3 mb-0">{mode === "login" ? <>New here? <Link to="/register">Register</Link></> : <>Already registered? <Link to="/login">Login</Link></>}</p>
  </div></div>;
}
function Dashboard({ user }) {
  const [farms,setFarms] = useState([]); const [crops,setCrops] = useState([]); const [orders,setOrders] = useState([]);
  const [farmForm,setFarmForm] = useState({farmName:"",location:"",areaAcres:"",soilType:"Loamy",irrigation:"Drip"});
  const [cropForm,setCropForm] = useState({name:"",season:"Kharif",status:"Growing",notes:""});
  const [orderForm,setOrderForm] = useState({item:"Seeds",quantity:1,notes:""});
  const [notice,setNotice] = useState(""); const [error,setError] = useState("");
  async function load() {
    try {
      const [f,c,o] = await Promise.all([api.get("/farms"),api.get("/crops"),api.get("/resources")]);
      setFarms(f.data.farms); setCrops(c.data.crops); setOrders(o.data.orders);
    } catch (e) { setError(e.response?.data?.message || "Could not load dashboard. Check backend/database."); }
  }
  useEffect(()=>{load();},[]);
  async function run(action, success) {
    setNotice(""); setError("");
    try { await action(); setNotice(success); await load(); }
    catch(e) { setError(e.response?.data?.message || "Action failed."); }
  }
  async function addFarm(e) { e.preventDefault(); await run(()=>api.post("/farms",{...farmForm,areaAcres:Number(farmForm.areaAcres||0)}),"Farm saved successfully."); setFarmForm({farmName:"",location:"",areaAcres:"",soilType:"Loamy",irrigation:"Drip"}); }
  async function addCrop(e) { e.preventDefault(); await run(()=>api.post("/crops",cropForm),"Crop saved successfully."); setCropForm({name:"",season:"Kharif",status:"Growing",notes:""}); }
  async function addOrder(e) { e.preventDefault(); await run(()=>api.post("/resources",{...orderForm,quantity:Number(orderForm.quantity)}),"Resource request submitted."); }
  return <div className="container py-4">
    <div className="d-flex flex-wrap justify-content-between align-items-center mb-4"><div><span className="eyebrow">FARMER WORKSPACE</span><h1 className="h2 mt-2">Namaste, {user?.name || "Farmer"} 👋</h1><p className="text-muted mb-0">Your farm information, all in one place.</p></div><span className="role-pill">{user?.role || "farmer"}</span></div>
    {notice && <div className="alert alert-success">{notice}</div>}{error && <div className="alert alert-danger">{error}</div>}
    <div className="row g-3 mb-4">{[[farms.length,"My Farms"],[crops.length,"Crop Records"],[orders.length,"Resource Requests"]].map(([n,label])=><div className="col-md-4" key={label}><div className="stat-card"><strong>{n}</strong><span>{label}</span></div></div>)}</div>
    <div className="row g-4">
      <div className="col-lg-6"><div className="panel"><h2 className="h5">＋ Add a farm</h2><form onSubmit={addFarm} className="d-grid gap-2">
        <input className="form-control" placeholder="Farm name" value={farmForm.farmName} onChange={e=>setFarmForm({...farmForm,farmName:e.target.value})} required/>
        <input className="form-control" placeholder="Village / district / location" value={farmForm.location} onChange={e=>setFarmForm({...farmForm,location:e.target.value})} required/>
        <input className="form-control" type="number" min="0" step="0.1" placeholder="Area (acres)" value={farmForm.areaAcres} onChange={e=>setFarmForm({...farmForm,areaAcres:e.target.value})}/>
        <div className="row g-2"><div className="col"><select className="form-select" value={farmForm.soilType} onChange={e=>setFarmForm({...farmForm,soilType:e.target.value})}>{["Loamy","Clay","Sandy","Black soil","Red soil","Unknown"].map(x=><option key={x}>{x}</option>)}</select></div><div className="col"><select className="form-select" value={farmForm.irrigation} onChange={e=>setFarmForm({...farmForm,irrigation:e.target.value})}>{["Drip","Canal","Borewell","Rain-fed","Sprinkler","Unknown"].map(x=><option key={x}>{x}</option>)}</select></div></div>
        <button className="btn btn-success">Save Farm</button></form>
        <hr/><h3 className="h6">Saved farms</h3>{farms.length===0?<p className="text-muted">No farms added yet.</p>:farms.map(f=><div className="list-row" key={f._id}><strong>{f.farmName}</strong><span>{f.location} · {f.areaAcres} acres · {f.soilType}</span><button className="btn btn-sm btn-outline-danger" onClick={()=>run(()=>api.delete(`/farms/${f._id}`),"Farm deleted.")}>Delete</button></div>)}</div></div>
      <div className="col-lg-6"><div className="panel"><h2 className="h5">＋ Track a crop</h2><form onSubmit={addCrop} className="d-grid gap-2">
        <input className="form-control" placeholder="Crop name (e.g. Wheat)" value={cropForm.name} onChange={e=>setCropForm({...cropForm,name:e.target.value})} required/>
        <div className="row g-2"><div className="col"><select className="form-select" value={cropForm.season} onChange={e=>setCropForm({...cropForm,season:e.target.value})}>{["Kharif","Rabi","Zaid","Year-round"].map(x=><option key={x}>{x}</option>)}</select></div><div className="col"><select className="form-select" value={cropForm.status} onChange={e=>setCropForm({...cropForm,status:e.target.value})}>{["Planned","Growing","Harvested"].map(x=><option key={x}>{x}</option>)}</select></div></div>
        <textarea className="form-control" placeholder="Notes (optional)" value={cropForm.notes} onChange={e=>setCropForm({...cropForm,notes:e.target.value})}/>
        <button className="btn btn-success">Save Crop</button></form>
        <hr/><h3 className="h6">Crop records</h3>{crops.length===0?<p className="text-muted">No crop records yet.</p>:crops.map(c=><div className="list-row" key={c._id}><strong>{c.name}</strong><span>{c.season} · {c.status}</span><button className="btn btn-sm btn-outline-danger" onClick={()=>run(()=>api.delete(`/crops/${c._id}`),"Crop deleted.")}>Delete</button></div>)}</div></div>
      <div className="col-lg-6"><div className="panel"><h2 className="h5">🌦️ Weather & pest watch</h2><p className="small text-muted">Illustrative demo data only — not live forecasts.</p>{demoWeather.map(w=><div className="weather-row" key={w.place}><div><strong>{w.place}</strong><div>{w.condition}</div><small>{w.note}</small></div><strong>{w.temp}</strong></div>)}<div className="alert alert-info mt-3 mb-0">Pest tip: inspect leaves regularly and consult a local agriculture expert before applying pesticides.</div></div></div>
      <div className="col-lg-6"><div className="panel"><h2 className="h5">🛒 Request farm resources</h2><form onSubmit={addOrder} className="d-grid gap-2"><select className="form-select" value={orderForm.item} onChange={e=>setOrderForm({...orderForm,item:e.target.value})}>{["Seeds","Organic fertilizer","Compost","Drip irrigation parts","Soil testing","Other"].map(x=><option key={x}>{x}</option>)}</select><input className="form-control" type="number" min="1" value={orderForm.quantity} onChange={e=>setOrderForm({...orderForm,quantity:e.target.value})} required/><input className="form-control" placeholder="Additional notes (optional)" value={orderForm.notes} onChange={e=>setOrderForm({...orderForm,notes:e.target.value})}/><button className="btn btn-success">Submit Request</button></form><hr/><h3 className="h6">My requests</h3>{orders.length===0?<p className="text-muted">No resource requests yet.</p>:orders.map(o=><div className="list-row" key={o._id}><strong>{o.item} × {o.quantity}</strong><span>{o.status}</span></div>)}</div></div>
      <div className="col-12"><div className="panel"><h2 className="h5">📈 Sample market reference</h2><p className="small text-muted">These figures are placeholders for UI demonstration. Verify current prices from official mandi sources.</p><div className="table-responsive"><table className="table align-middle mb-0"><thead><tr><th>Crop</th><th>Sample price</th><th>Data type</th></tr></thead><tbody>{market.map(m=><tr key={m.crop}><td>{m.crop}</td><td>{m.price}</td><td><span className="badge text-bg-warning">{m.source}</span></td></tr>)}</tbody></table></div></div></div>
    </div>
  </div>;
}
export default function App() {
  const [user,setUser] = useState(()=>{ try { return JSON.parse(localStorage.getItem("agritech_user") || "null"); } catch { return null; } });
  function authUser(u) { setUser(u); localStorage.setItem("agritech_user",JSON.stringify(u)); }
  function logout() { localStorage.removeItem("agritech_token"); localStorage.removeItem("agritech_user"); setUser(null); }
  return <><Header user={user} logout={logout}/><Routes>
    <Route path="/" element={<Home/>}/>
    <Route path="/login" element={<AuthForm mode="login" onAuth={authUser}/>}/>
    <Route path="/register" element={<AuthForm mode="register" onAuth={authUser}/>}/>
    <Route path="/dashboard" element={user ? <Dashboard user={user}/> : <AuthForm mode="login" onAuth={authUser}/>}/>
    <Route path="*" element={<Home/>}/>
  </Routes><footer className="app-footer"><div className="container">AgriSmart · AgriTech – Empowering Farmers <span>Built as a MERN learning project</span></div></footer></>;
}
