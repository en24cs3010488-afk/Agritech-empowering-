import mongoose from "mongoose";

const resourceOrderSchema = new mongoose.Schema({
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  item: { type: String, required: true, trim: true },
  quantity: { type: Number, required: true, min: 1 },
  notes: { type: String, default: "" },
  status: { type: String, enum: ["Requested", "Approved", "Delivered", "Cancelled"], default: "Requested" }
}, { timestamps: true });

export default mongoose.model("ResourceOrder", resourceOrderSchema);
