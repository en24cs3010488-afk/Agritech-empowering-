import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ["farmer", "admin"], default: "farmer" },
  phone: { type: String, default: "" },
  language: { type: String, default: "English" }
}, { timestamps: true });

export default mongoose.model("User", userSchema);
