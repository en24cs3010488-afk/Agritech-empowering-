import { Router } from "express";
import Farm from "../models/Farm.js";
import { protect } from "../middleware/auth.js";

const router = Router();
router.use(protect);

router.get("/", async (req, res, next) => {
  try { res.json({ farms: await Farm.find({ owner: req.user.id }).sort({ createdAt: -1 }) }); }
  catch (err) { next(err); }
});
router.post("/", async (req, res, next) => {
  try {
    const { farmName, location, areaAcres, soilType, irrigation } = req.body;
    if (!farmName?.trim() || !location?.trim()) return res.status(400).json({ message: "Farm name and location are required." });
    const farm = await Farm.create({ owner: req.user.id, farmName, location, areaAcres, soilType, irrigation });
    res.status(201).json({ farm });
  } catch (err) { next(err); }
});
router.put("/:id", async (req, res, next) => {
  try {
    const farm = await Farm.findOneAndUpdate(
      { _id: req.params.id, owner: req.user.id }, req.body,
      { new: true, runValidators: true }
    );
    if (!farm) return res.status(404).json({ message: "Farm not found." });
    res.json({ farm });
  } catch (err) { next(err); }
});
router.delete("/:id", async (req, res, next) => {
  try {
    const farm = await Farm.findOneAndDelete({ _id: req.params.id, owner: req.user.id });
    if (!farm) return res.status(404).json({ message: "Farm not found." });
    res.json({ message: "Farm deleted." });
  } catch (err) { next(err); }
});
export default router;
