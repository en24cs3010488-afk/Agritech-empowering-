import { Router } from "express";
import Crop from "../models/Crop.js";
import { protect } from "../middleware/auth.js";

const router = Router();
router.use(protect);

router.get("/", async (req, res, next) => {
  try { res.json({ crops: await Crop.find({ owner: req.user.id }).populate("farm", "farmName location").sort({ createdAt: -1 }) }); }
  catch (err) { next(err); }
});
router.post("/", async (req, res, next) => {
  try {
    if (!req.body.name?.trim()) return res.status(400).json({ message: "Crop name is required." });
    const crop = await Crop.create({ ...req.body, owner: req.user.id });
    res.status(201).json({ crop });
  } catch (err) { next(err); }
});
router.put("/:id", async (req, res, next) => {
  try {
    const crop = await Crop.findOneAndUpdate({ _id: req.params.id, owner: req.user.id }, req.body, { new: true, runValidators: true });
    if (!crop) return res.status(404).json({ message: "Crop not found." });
    res.json({ crop });
  } catch (err) { next(err); }
});
router.delete("/:id", async (req, res, next) => {
  try {
    const crop = await Crop.findOneAndDelete({ _id: req.params.id, owner: req.user.id });
    if (!crop) return res.status(404).json({ message: "Crop not found." });
    res.json({ message: "Crop deleted." });
  } catch (err) { next(err); }
});
export default router;
