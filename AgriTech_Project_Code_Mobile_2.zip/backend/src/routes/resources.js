import { Router } from "express";
import ResourceOrder from "../models/ResourceOrder.js";
import { protect, adminOnly } from "../middleware/auth.js";

const router = Router();
router.use(protect);
router.get("/", async (req, res, next) => {
  try {
    const filter = req.user.role === "admin" ? {} : { owner: req.user.id };
    res.json({ orders: await ResourceOrder.find(filter).populate("owner", "name email").sort({ createdAt: -1 }) });
  } catch (err) { next(err); }
});
router.post("/", async (req, res, next) => {
  try {
    const { item, quantity, notes } = req.body;
    if (!item?.trim() || !Number.isFinite(Number(quantity)) || Number(quantity) < 1) {
      return res.status(400).json({ message: "Item and a quantity of at least 1 are required." });
    }
    const order = await ResourceOrder.create({ owner: req.user.id, item, quantity, notes });
    res.status(201).json({ order });
  } catch (err) { next(err); }
});
router.patch("/:id/status", adminOnly, async (req, res, next) => {
  try {
    const allowed = ["Requested", "Approved", "Delivered", "Cancelled"];
    if (!allowed.includes(req.body.status)) return res.status(400).json({ message: "Invalid order status." });
    const order = await ResourceOrder.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true, runValidators: true });
    if (!order) return res.status(404).json({ message: "Order not found." });
    res.json({ order });
  } catch (err) { next(err); }
});
export default router;
