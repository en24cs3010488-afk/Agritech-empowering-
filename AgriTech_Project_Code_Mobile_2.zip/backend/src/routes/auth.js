import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/User.js";
import { protect, adminOnly } from "../middleware/auth.js";

const router = Router();
const safeUser = (user) => ({
  id: user._id, name: user.name, email: user.email, role: user.role,
  phone: user.phone, language: user.language
});
const makeToken = (user) => jwt.sign(
  { id: user._id.toString(), name: user.name, role: user.role },
  process.env.JWT_SECRET || "development_only_secret",
  { expiresIn: "2d" }
);

router.post("/register", async (req, res, next) => {
  try {
    const { name, email, password, phone, language } = req.body;
    if (!name?.trim() || !email?.trim() || !password) {
      return res.status(400).json({ message: "Name, email and password are required." });
    }
    if (password.length < 8) return res.status(400).json({ message: "Password must be at least 8 characters." });
    const user = await User.create({
      name, email, phone, language, passwordHash: await bcrypt.hash(password, 12)
    });
    res.status(201).json({ token: makeToken(user), user: safeUser(user) });
  } catch (err) { next(err); }
});

router.post("/login", async (req, res, next) => {
  try {
    const user = await User.findOne({ email: String(req.body.email || "").toLowerCase().trim() });
    if (!user || !(await bcrypt.compare(req.body.password || "", user.passwordHash))) {
      return res.status(401).json({ message: "Invalid email or password." });
    }
    res.json({ token: makeToken(user), user: safeUser(user) });
  } catch (err) { next(err); }
});

router.get("/me", protect, async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ message: "User not found." });
    res.json({ user: safeUser(user) });
  } catch (err) { next(err); }
});

router.get("/admin/users", protect, adminOnly, async (_req, res, next) => {
  try {
    const users = await User.find().select("-passwordHash").sort({ createdAt: -1 }).limit(200);
    res.json({ users });
  } catch (err) { next(err); }
});

export default router;
