import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import mongoose from "mongoose";
import authRoutes from "./src/routes/auth.js";
import farmRoutes from "./src/routes/farms.js";
import cropRoutes from "./src/routes/crops.js";
import resourceRoutes from "./src/routes/resources.js";
import { errorHandler } from "./src/middleware/errorHandler.js";

dotenv.config();
const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5173" }));
app.use(express.json());

app.get("/api/health", (_req, res) => res.json({ status: "ok", app: "AgriTech API" }));
app.use("/api/auth", authRoutes);
app.use("/api/farms", farmRoutes);
app.use("/api/crops", cropRoutes);
app.use("/api/resources", resourceRoutes);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;
mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/agritech")
  .then(() => {
    console.log("MongoDB connected");
    app.listen(PORT, () => console.log(`AgriTech API running on http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error("MongoDB connection failed:", err.message);
    process.exit(1);
  });
